# maven-project
Example of maven project for Jenkins
